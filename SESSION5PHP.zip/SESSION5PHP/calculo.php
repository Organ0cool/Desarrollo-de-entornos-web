<?php
echo "Resultado";
$n1=$_POST['n1'];
$n2=$_POST['n2'];         
$n3=$_POST['n3'];
$ope= $_POST['ope'];

if($ope=='my'){
    $my=$n1;
    if($n2>$my)
        $my=$n2;
    if ($n3 > $n2);
        $my = $n3;
    echo " el mayor es ", $my;
}
if($ope==' mn '){
    $mn=$n1;
    if($n2>$mn)
        $mn=$n2;
    if ($n3 > $n2);
        $mn = $n3;
    echo " el menor es ", $mn;
}
if($ope==' ct '){
    $ct=$n1;
    if($n2>$ct)
        $ct=$n2;
    if ($n3 > $n2);
        $ct = $n3;
    echo " el menor es ", $ct;
}

if ($ope == 'sum') {
    $mn = $n1;
    if ($n2 < $mn) 
        $mn = $n2;
    if ($n3 < $mn)
        $mn = $n3;
    $suma = 0;
    for ($i = 1; $i <= $mn; $i++) {
        $suma += $i;
    }
    echo " La suma de 1 hasta $mn es: $suma";
}
if ($ope == 'sum1') {
    $mn = $n1;
    if ($n2 < $mn)
        $mn = $n2;
    if ($n3 < $mn)
        $mn = $n3;

    $my = $n1;
    if ($n2 > $my)
        $my = $n2;
    if ($n3 > $my)
        $my = $n3;

    $suma = 0;

    for ($i = $mn; $i <= $my; $i++)
        $suma = $suma + $i;

    echo "La suma desde $mn hasta $my es: $suma";
}
echo $ope;
