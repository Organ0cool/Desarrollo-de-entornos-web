<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Ingresar números</title>
</head>
<body>

<h1>Ingresa tres números</h1>

<form action="calculo.php" method="post">
  <input type="text" name="n1" placeholder="Numero 1"> <br>
  <input type="text" name="n2" placeholder="Numero 2"> <br>
  <input type="text" name="n3" placeholder="Numero 3"> <br>
  <select name="ope" id="ope">
    <option value="my">Mayor</option>
    <option value="ct">Central</option>
    <option value="mn">Menor</option>
    <option value="sum">Sumatoria de 1 hasta el Menor</option>
    <option value="sum1">Sumatoria de menor hasta el Mayor</option>
  </select><br>
  <input type="submit">
</form>

</body>
</html>
